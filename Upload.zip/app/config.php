<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', 'fzresult_socialement');
define('DB_PASS', '8my)7Ib4u,o0');
define('DB_NAME', 'fzresult_socialement');
define('TIMEZONE', 'Africa/Abidjan');
define('ENCRYPTION_KEY', '25c7aa4e16660d8a972c9953239c055b');
